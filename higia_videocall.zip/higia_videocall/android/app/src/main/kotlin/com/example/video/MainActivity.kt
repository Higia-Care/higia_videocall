package com.example.video

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
